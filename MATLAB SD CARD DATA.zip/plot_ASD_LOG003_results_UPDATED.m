%% Autonomous Sailboat Experimental Results Graphs
% This script reads LOG003_Final.CSV and creates report-ready graphs.
%
% Put this .m file in the same folder as LOG003_Final.CSV, then Run.

clear; clc; close all;

%% 1) User settings
filename = 'LOG003_Final.CSV';
outDir = 'ASD_LOG003_Graphs_Target';

% target waypoint in local coordinates relative to home
correctedTargetEast_m  = 101.00;     % X-axis / East position from home (m)
correctedTargetNorth_m = -47.45;     % Y-axis / North position from home (m)

% Distance threshold used to decide that the target has been reached.
% Your log reaches within about 0.4 m of the corrected target, so 1 m is suitable.
targetReachRadius_m = 1.0;

if ~exist(outDir, 'dir')
    mkdir(outDir);
end

%% 2) Load CSV log
opts = detectImportOptions(filename);
Traw = readtable(filename, opts);

%% 3) Prepare time and valid GPS data
Traw.Time_s = (Traw.Time_ms - Traw.Time_ms(1)) ./ 1000;

validGPSraw = Traw.GPSFix == 1 & Traw.Latitude ~= 0 & Traw.Longitude ~= 0 & ...
              ~isnan(Traw.Latitude) & ~isnan(Traw.Longitude);

% Find home coordinates from the first non-zero values in the log
homeLat = firstNonZero(Traw.HomeLat);
homeLon = firstNonZero(Traw.HomeLon);

% If home was not logged correctly, use the first valid GPS point as reference
if isnan(homeLat) || isnan(homeLon)
    firstGPS = find(validGPSraw, 1, 'first');
    homeLat = Traw.Latitude(firstGPS);
    homeLon = Traw.Longitude(firstGPS);
end

%% 4) Convert latitude/longitude to local East-North coordinates in metres
R = 6371000; % Earth radius in metres
refLat = homeLat;
refLon = homeLon;

Traw.East_m  = R .* cosd(refLat) .* deg2rad(Traw.Longitude - refLon);
Traw.North_m = R .* deg2rad(Traw.Latitude - refLat);

% Hide invalid GPS points in local coordinates so they do not affect graphs/metrics
Traw.East_m(~validGPSraw)  = NaN;
Traw.North_m(~validGPSraw) = NaN;

%% 5) Recalculate navigation quantities for the corrected target
Traw.DistanceToCorrectedTarget_m = hypot(correctedTargetEast_m - Traw.East_m, ...
                                         correctedTargetNorth_m - Traw.North_m);

% Bearing convention: 0 deg = North, 90 deg = East
Traw.BearingToCorrectedTarget_deg = mod(atan2d(correctedTargetEast_m - Traw.East_m, ...
                                               correctedTargetNorth_m - Traw.North_m), 360);
Traw.DesiredHeadingCorrected_deg = Traw.BearingToCorrectedTarget_deg;
Traw.HeadingErrorCorrected_deg = wrapTo180Local(Traw.DesiredHeadingCorrected_deg - Traw.Heading_deg);

% Remove corrected navigation values for invalid GPS rows
Traw.DistanceToCorrectedTarget_m(~validGPSraw) = NaN;
Traw.BearingToCorrectedTarget_deg(~validGPSraw) = NaN;
Traw.DesiredHeadingCorrected_deg(~validGPSraw) = NaN;
Traw.HeadingErrorCorrected_deg(~validGPSraw) = NaN;

%% 6) Trim the log after the corrected target is reached
reachCandidates = find(validGPSraw & Traw.DistanceToCorrectedTarget_m <= targetReachRadius_m);

if ~isempty(reachCandidates)
    reachIdx = reachCandidates(1); % first time target is reached
    trimReason = sprintf('first point within %.2f m of corrected target', targetReachRadius_m);
else
    % Fallback: if the threshold is not reached, trim at closest approach
    [~, localMinIdx] = min(Traw.DistanceToCorrectedTarget_m(validGPSraw));
    validIdx = find(validGPSraw);
    reachIdx = validIdx(localMinIdx);
    trimReason = 'closest approach because target radius was not reached';
end

T = Traw(1:reachIdx, :);
t = T.Time_s;
validGPS = T.GPSFix == 1 & ~isnan(T.East_m) & ~isnan(T.North_m);
validDist = validGPS & ~isnan(T.DistanceToCorrectedTarget_m);
validHeading = ~isnan(T.HeadingErrorCorrected_deg);

fprintf('Corrected target waypoint: East/X = %.2f m, North/Y = %.2f m\n', ...
    correctedTargetEast_m, correctedTargetNorth_m);
fprintf('Trimmed at sample %d, time %.2f s: %s.\n', reachIdx, Traw.Time_s(reachIdx), trimReason);
fprintf('Distance from corrected target at trim point: %.3f m\n\n', ...
    Traw.DistanceToCorrectedTarget_m(reachIdx));

%% 7) Basic performance summary for report table
summaryMetric = {
    'Total raw samples';
    'Samples used after target trimming';
    'Trim time / target reached time (s)';
    'Trim time / target reached time (min)';
    'Corrected target East/X position (m)';
    'Corrected target North/Y position (m)';
    'Target reach radius used (m)';
    'Valid GPS samples used';
    'Initial corrected distance to target (m)';
    'Minimum corrected distance to target (m)';
    'Final corrected distance to target (m)';
    'Mean absolute corrected heading error (deg)';
    'Maximum absolute corrected heading error (deg)';
    'Mean satellites during valid GPS';
    'Maximum satellites';
    'Mean wind speed';
    'Maximum wind speed';
    'Rudder angle minimum (deg)';
    'Rudder angle maximum (deg)';
    'Sail angle minimum (deg)';
    'Sail angle maximum (deg)'};

firstValidDistIdx = find(validDist, 1, 'first');
lastValidDistIdx  = find(validDist, 1, 'last');

summaryValue = [
    height(Traw);
    height(T);
    max(t) - min(t);
    (max(t) - min(t))/60;
    correctedTargetEast_m;
    correctedTargetNorth_m;
    targetReachRadius_m;
    sum(validGPS);
    T.DistanceToCorrectedTarget_m(firstValidDistIdx);
    min(T.DistanceToCorrectedTarget_m(validDist), [], 'omitnan');
    T.DistanceToCorrectedTarget_m(lastValidDistIdx);
    mean(abs(T.HeadingErrorCorrected_deg(validHeading)), 'omitnan');
    max(abs(T.HeadingErrorCorrected_deg(validHeading)), [], 'omitnan');
    mean(T.Satellites(validGPS), 'omitnan');
    max(T.Satellites, [], 'omitnan');
    mean(T.WindSpeed, 'omitnan');
    max(T.WindSpeed, [], 'omitnan');
    min(T.RudderAngle_deg, [], 'omitnan');
    max(T.RudderAngle_deg, [], 'omitnan');
    min(T.SailAngle_deg, [], 'omitnan');
    max(T.SailAngle_deg, [], 'omitnan')];

Summary = table(summaryMetric, summaryValue, ...
    'VariableNames', {'Metric','Value'});
writetable(Summary, fullfile(outDir, 'LOG003_corrected_target_summary_metrics.csv'));
disp(Summary);

%% Figure 1: GPS trajectory/path of the sailboat
figure('Color','w');
plot(T.East_m(validGPS), T.North_m(validGPS), '-o', 'LineWidth', 1.2, 'MarkerSize', 3);
hold on;
plot(0, 0, 'kp', 'MarkerSize', 12, 'MarkerFaceColor', 'k');
plot(correctedTargetEast_m, correctedTargetNorth_m, 'rp', 'MarkerSize', 12, 'MarkerFaceColor', 'r');

grid on; axis equal;
xlabel('East position from home (m)');
ylabel('North position from home (m)');
title('Autonomous Sailboat GPS Trajectory to Target');
legend('Boat path', 'Home position', 'target waypoint', 'Location', 'best');
saveFigure(outDir, 'Fig01_GPS_Trajectory_Target');

%% Figure 2: distance to target over time
figure('Color','w');
plot(t(validDist), T.DistanceToCorrectedTarget_m(validDist), 'LineWidth', 1.5);
hold on;
ylineCompat(targetReachRadius_m, 'k--');
grid on;
xlabel('Time (s)');
ylabel('distance to target (m)');
title('Distance to Target During Autonomous Navigation');
legend('distance to target', 'Target reach radius', 'Location', 'best');
saveFigure(outDir, 'Fig02_Distance_To_Target');

%% Figure 3: Actual heading compared with desired heading
figure('Color','w');
plot(t, mod(T.Heading_deg, 360), 'LineWidth', 1.3);
hold on;
plot(t, mod(T.DesiredHeadingCorrected_deg, 360), '--', 'LineWidth', 1.3);
grid on;
xlabel('Time (s)');
ylabel('Heading angle (deg)');
ylim([0 360]);
title('Actual Heading Compared with Desired Heading');
legend('Actual heading', 'desired heading', 'Location', 'best');
saveFigure(outDir, 'Fig03_Heading_vs_Desired_Heading');

%% Figure 4: heading error and rudder response
figure('Color','w');
yyaxis left;
plot(t, T.HeadingErrorCorrected_deg, 'LineWidth', 1.3);
ylabel('heading error (deg)');
ylineCompat(0, 'k--');

yyaxis right;
plot(t, T.RudderAngle_deg, 'LineWidth', 1.3);
ylabel('Rudder angle (deg)');

grid on;
xlabel('Time (s)');
title('Heading Error and Rudder Control Response');
legend('heading error', 'Zero error reference', 'Rudder angle', 'Location', 'best');
saveFigure(outDir, 'Fig04_Heading_Error_Rudder_Response');

%% Figure 5: Rudder and sail actuator commands
figure('Color','w');
plot(t, T.RudderAngle_deg, 'LineWidth', 1.4);
hold on;
plot(t, T.SailAngle_deg, '--', 'LineWidth', 1.4);
grid on;
xlabel('Time (s)');
ylabel('Actuator angle (deg)');
title('Rudder and Sail Actuator Commands Before Target Reached');
legend('Rudder angle', 'Sail angle', 'Location', 'best');
saveFigure(outDir, 'Fig05_Actuator_Commands');

%% Figure 6: Wind condition and relative wind angle
figure('Color','w');
yyaxis left;
plot(t, T.RelativeWindAngle_deg, 'LineWidth', 1.3);
ylabel('Relative wind angle (deg)');
ylineCompat(0, 'k--');

yyaxis right;
plot(t, T.WindSpeed, 'LineWidth', 1.3);
ylabel('Wind speed');

grid on;
xlabel('Time (s)');
title('Wind Conditions Before Target Reached');
legend('Relative wind angle', 'Zero reference', 'Wind speed', 'Location', 'best');
saveFigure(outDir, 'Fig06_Wind_Conditions');

%% Figure 7: GPS quality: satellites and GPS age
GPSAge_plot = T.GPSAge_ms;
GPSAge_plot(GPSAge_plot > 10000) = NaN; % hide very large invalid-age values

figure('Color','w');
yyaxis left;
stairs(t, T.Satellites, 'LineWidth', 1.3);
ylabel('Number of satellites');

yyaxis right;
plot(t, GPSAge_plot, 'LineWidth', 1.3);
ylabel('GPS age (ms)');

grid on;
xlabel('Time (s)');
title('GPS Signal Quality Before Target Reached');
legend('Satellites', 'GPS age', 'Location', 'best');
saveFigure(outDir, 'Fig07_GPS_Quality');

%% Figure 8: Boat pitch and roll response
figure('Color','w');
plot(t, T.Pitch_deg, 'LineWidth', 1.3);
hold on;
plot(t, T.Roll_deg, 'LineWidth', 1.3);
grid on;
xlabel('Time (s)');
ylabel('Angle (deg)');
title('Boat Attitude Before Target Reached: Pitch and Roll');
legend('Pitch', 'Roll', 'Location', 'best');
saveFigure(outDir, 'Fig08_Pitch_Roll');

%% Figure 9: Corrected heading error distribution
figure('Color','w');
histogram(T.HeadingErrorCorrected_deg(validHeading), 20);
grid on;
xlabel('heading error (deg)');
ylabel('Number of samples');
title('Distribution of Heading Error Before Target Reached');
saveFigure(outDir, 'Fig09_Heading_Error_Distribution');

%% Figure 10: Rudder angle versus heading error
figure('Color','w');
scatter(T.HeadingErrorCorrected_deg(validHeading), T.RudderAngle_deg(validHeading), 20, 'filled');
grid on;
xlabel('heading error (deg)');
ylabel('Rudder angle (deg)');
title('Relationship Between Heading Error and Rudder Angle');
saveFigure(outDir, 'Fig10_Rudder_vs_Heading_Error');

fprintf('\nGraphs and summary metrics saved in folder: %s\n', outDir);

%% -------- Local helper functions --------
function value = firstNonZero(x)
    idx = find(~isnan(x) & x ~= 0, 1, 'first');
    if isempty(idx)
        value = NaN;
    else
        value = x(idx);
    end
end

function a = wrapTo180Local(a)
    % Wrap angle to [-180, 180] without requiring Mapping Toolbox.
    a = mod(a + 180, 360) - 180;
end

function saveFigure(outDir, fileBase)
    pngFile = fullfile(outDir, [fileBase '.png']);
    figFile = fullfile(outDir, [fileBase '.fig']);
    print(gcf, pngFile, '-dpng', '-r300');
    savefig(gcf, figFile);
end

function ylineCompat(y, style)
    % Uses yline when available; otherwise draws a horizontal reference line.
    if exist('yline', 'file') == 2 || exist('yline', 'builtin') == 5
        yline(y, style);
    else
        xl = xlim;
        line(xl, [y y], 'LineStyle', '--', 'Color', 'k');
    end
end
